<?php

	define('IN_LCMS', 'Yeap');

	//LCMS Version
	define('LCMS_VERSION', '2.0.4');

	//Path to the themes folder
	define('THEMES', 'themes/');

	//Path to the modules folder
	define('MODULES', 'inc/modules/');

	//Path to the language folder
	define('LANG', 'inc/lang/'.$this->language.'/');

?>