<?php

$lang['contact']['firstname'] = 'Imię';
$lang['contact']['lastname'] = 'Nazwisko';
$lang['contact']['mail'] = 'E-Mail';
$lang['contact']['subject'] = 'Temat';
$lang['contact']['content'] = 'Treść';
$lang['contact']['send'] = 'Wyślij';
$lang['contact']['empty inputs'] = 'Należy wypełnić wszystkie pola';
$lang['contact']['invalid mail'] = 'Wprowadzony adres jest niepoprawny';
$lang['contact']['send success'] = 'Wiadomość została poprawnie wysłana';
$lang['contact']['send fail'] = 'Niestety nie udało się wysłać wiadomości';

?>