<?php

$lang['pages']['no pages'] = 'Brak stron';
$lang['pages']['no pages desc'] = 'Nie dodano jeszcze żadnej strony. Zaloguj się do panelu administracyjnego i dodaj nową stronę.';
$lang['pages']['error 404'] = 'Błąd 404';
$lang['pages']['error 404 desc'] = 'Taka strona nie istnieje.';

?>