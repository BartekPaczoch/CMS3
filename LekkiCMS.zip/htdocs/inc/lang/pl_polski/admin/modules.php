<?php

$lang['modules']['modules'] = 'Moduły';
$lang['modules']['modules_desc'] = 'Zarządzanie modułami';
$lang['modules']['active'] = 'Aktywne';
$lang['modules']['unactive'] = 'Nieaktywne';
$lang['modules']['name'] = 'Nazwa';
$lang['modules']['desc'] = 'Opis';
$lang['modules']['author'] = 'Autor';
$lang['modules']['options'] = 'Akcje';
$lang['modules']['module doesnt exist'] = 'Taki moduł nie istnieje';
$lang['modules']['module deactive success'] = 'Moduł został pomyślnie dezaktywowany';
$lang['modules']['module deactive fail'] = 'Nie udało się dezaktywować modułu';
$lang['modules']['module active success'] = 'Moduł został pomyślnie aktywowany';
$lang['modules']['module active fail'] = 'Nie udało się aktywować modułu';
$lang['modules']['cant deactive'] = 'Nie możesz dezaktywować tego modułu';
$lang['modules']['module already active'] = 'Taki moduł jest już aktywowany';

?>