<?php

$lang['example']['Hello World'] = 'Witaj Świecie';

?>