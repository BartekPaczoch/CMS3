<?php

$lang['contact']['contact'] = 'Kontakt';
$lang['contact']['contact desc'] = 'Wyświetla formularz kontaktowy';
$lang['contact']['options'] = 'Ustawienia';
$lang['contact']['choice of e-mail'] = 'Wybierz użytkownika lub wpisz adres e-mail ręcznie, na który będą dostarczane wiadomości.';
$lang['contact']['info'] = 'Następnie wklej {{contact.form}} na wybraną podstronę, aby wyświetlić formularz.';
$lang['contact']['user'] = 'Użytkownik';
$lang['contact']['user desc'] = 'Wybierz';
$lang['contact']['mail'] = 'Lub Mail';
$lang['contact']['mail desc'] = 'Adres e-mail';
$lang['contact']['can be empty'] = 'Może pozostać puste';
$lang['contact']['save'] = 'Zapisz';
$lang['contact']['invalid mail'] = 'Wpisany mail jest niepoprawny';
$lang['contact']['save success'] = 'Pomyślnie zapisano dane';
$lang['contact']['save fail'] = 'Nie udało się zapisać danych';

?>