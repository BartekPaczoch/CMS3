<?php

$lang['news']['read more'] = 'Czytaj dalej';
$lang['news']['news doesnt exist'] = 'Taki post nie istnieje.';

?>